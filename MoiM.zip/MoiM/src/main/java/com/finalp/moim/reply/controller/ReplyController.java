package com.finalp.moim.reply.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.finalp.moim.reply.model.service.ReplyService;

@Controller
public class ReplyController {
	// Logger
	private static final Logger logger = LoggerFactory.getLogger(ReplyController.class);
	
	// DI
	@Autowired
	private ReplyService replyService;
}
