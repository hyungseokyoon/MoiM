package com.finalp.moim.reply.model.service;

public interface ReplyService {

}
