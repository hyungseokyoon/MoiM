package com.finalp.moim.board.model.service;

public interface BoardService {

}
