package com.finalp.moim.join.controller;

public class JoinController {

}
