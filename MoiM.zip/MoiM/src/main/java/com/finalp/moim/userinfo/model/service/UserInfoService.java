package com.finalp.moim.userinfo.model.service;

public interface UserInfoService {

}
