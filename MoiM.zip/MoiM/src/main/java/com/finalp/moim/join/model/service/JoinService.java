package com.finalp.moim.join.model.service;

public interface JoinService {

}
