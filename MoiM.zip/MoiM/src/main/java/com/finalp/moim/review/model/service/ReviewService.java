package com.finalp.moim.review.model.service;

public interface ReviewService {

}
