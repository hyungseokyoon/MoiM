package com.finalp.moim.notice.model.service;

public interface NoticeService {

}
